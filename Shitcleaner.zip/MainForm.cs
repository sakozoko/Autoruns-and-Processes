﻿using Shitcleaner.Properties;
using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Shitcleaner
{
    partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            InitializateButtonMaximizeImages();
            FormUpg.SmoothViewForm(this);
        }


        private void InitializateButtonMaximizeImages()
        {
            ImageList imgList = new ImageList();
            imgList.Images.AddRange(new System.Drawing.Image[] {
                Resources.maximum,
                Resources.minimum
            });
            butMaximize.ImageList = imgList;
            butMaximize.ImageIndex = 0;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            FormUpg.RewriteProcessNamesToListBox(checkList);
        }

        private void ButAddProcNamesToFile_Click(object sender, EventArgs e)
        {
            FileWork.AddProcNames(checkList.GetTextCheckeds());
            FormUpg.RewriteProcessNamesToListBox(checkList);
        }


        private void ButRefreshListBox_Click(object sender, EventArgs e)
        {
            FormUpg.RewriteProcessNamesToListBox(checkList);
        }


        private void MainForm_Deactivate(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Minimized)
            {
                notifyIcon.Visible = true;
                ShowInTaskbar = false;
            }
        }


        private void ButShowSavedProc_Click(object sender, EventArgs e)
        {
            new FSavedProc().ShowDialog();
        }


        private void ButCleanProcesses_Click(object sender, EventArgs e)
        {
            BeforeClean();
        }

        private void CleanProcessesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BeforeClean();
        }

        private void BeforeClean()
        {
            
            FMessage fr = new FMessage("Закрыть процессы", $"Вы действительно хотите закрыть ({checkList.GetTextCheckeds().Count})",
                IconFMessage.Kill, ButtonFMessage.YesBack);
            if (fr.FShowDialog(this) == DialogResult.Yes)
            {
                CleanProc();
            }
        }

        private void CleanProc()
        {
            FileWork.AddProcNames(checkList.GetTextCheckeds());
            Processes.ProcessesKill(checkList.GetTextCheckeds());
            new FMessage("Готово", "Процессы были удалены", IconFMessage.Kill, ButtonFMessage.OK).FShowDialog(this);
            FormUpg.RewriteProcessNamesToListBox(checkList);
        }


        private void NotifyIcon_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            OpenToolStripMenuItem_Click(sender, e);
        }

        private void OpenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormUpg.SmoothViewFormMinNorm(this);
            notifyIcon.Visible = false;
            ShowInTaskbar = true;
            butMinimize.Enabled = true;
        }


        private void CloseProgramToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void ButCloseProgram_Click(object sender, EventArgs e)
        {
            checkList.Focus();
            FMessage fr = new FMessage("Выход", "Вы действительно хотите выйти?", IconFMessage.Exit, ButtonFMessage.YesBack);
            if (fr.FShowDialog(this) == DialogResult.Yes)
            {
                FormUpg.SmoothViewFormClose(this);
            }
        }

        private void ButMaximize_Click(object sender, EventArgs e)
        {
            butMaximize.ImageIndex = (butMaximize.ImageIndex == 1) ? 0 : 1;
            WindowState = (butMaximize.ImageIndex == 1) ? FormWindowState.Maximized : FormWindowState.Normal;
        }


        private void ButMinimize_Click(object sender, EventArgs e)
        {
            FormUpg.SmoothViewFormMinNorm(this);
            butMinimize.Enabled = false;
        }


        private void PanelTitle_MouseDown(object sender, MouseEventArgs e)
        {
            FormUpg.FormMove.PanelTitle_MouseDown(sender, e, this);
        }

        private void PanelTitle_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FormUpg.FormMove.PanelTitle_MouseDoubleClick(sender, e);
        }

        private void PanelTitle_MouseMove(object sender, MouseEventArgs e)
        {
            FormUpg.FormMove.PanelTitle_MouseMove(sender, e);
        }

    }



}
