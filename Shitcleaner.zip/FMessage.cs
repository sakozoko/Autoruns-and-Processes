﻿using System;
using System.Windows.Forms;

namespace Shitcleaner
{
    public enum IconFMessage
    {
        Exit = 0,
        Kill = 1,
        Notification = 2
    }
    public enum ButtonFMessage
    {
        OK = 0,
        YesBack = 1
    }

    public partial class FMessage : Form
    {
        DialogResult dialog;
        public FMessage()
        {
            InitializeComponent();
        }
        public FMessage(string textTitle, string textLabel, IconFMessage icon, ButtonFMessage button)
        {
            InitializeComponent();
            labelTitle.Text = textTitle;
            label.Text = textLabel;
            this.icon.Image = GetIcon(icon);
            GetButton(button);

        }

        private System.Drawing.Bitmap GetIcon(IconFMessage icon)
        {
            if (icon == IconFMessage.Exit)
            {
                return Properties.Resources.exitimg;
            }
            else if (icon == IconFMessage.Kill)
            {
                return Properties.Resources.killimg;
            }
            else if (icon == IconFMessage.Notification)
            {
                return Properties.Resources.notification;
            }
            else
            {
                return Properties.Resources.notification;
            }
        }

        private void GetButton(ButtonFMessage button)
        {
            if (button == ButtonFMessage.OK)
            {
                butOK.Visible = true;
            }

            if (button == ButtonFMessage.YesBack)
            {
                buttonYes.Visible = true;
                buttonBack.Visible = true;
            }
        }


        public DialogResult FShowDialog(Form parent)
        {
            GetStartPositon(parent);
            FormUpg.SmoothViewForm(this);
            ShowDialog();
            return dialog;  
        }

        private void GetStartPositon(Form parent)
        {
            if (parent.WindowState == FormWindowState.Minimized)
            {
                StartPosition = FormStartPosition.CenterScreen;
            }
            else
            {
                StartPosition = FormStartPosition.CenterParent;
            }
        }


        private void ButYes_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Yes;
            dialog = DialogResult.Yes;
        }

        private void ButBack_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.No;
            dialog = DialogResult;
        }

        private void ButOK_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
            dialog = DialogResult;
        }

        private void FMessage_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.None)
            {
                e.Cancel = true;
                FormUpg.SmoothViewFormClose(this);
            }
        }

        private void panelTitle_MouseDown(object sender, MouseEventArgs e)
        {
            FormUpg.FormMove.PanelTitle_MouseDown(sender, e, this);
        }

        private void panelTitle_MouseMove(object sender, MouseEventArgs e)
        {
            FormUpg.FormMove.PanelTitle_MouseMove(sender, e);
        }
    }
}
