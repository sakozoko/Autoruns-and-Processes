﻿using System;
using System.Windows.Forms;

namespace Shitcleaner
{
    public partial class FSavedProc : Form
    {
        public FSavedProc()
        {
            InitializeComponent();
            FormUpg.SmoothViewForm(this);
        }


        private void FSavedProc_Load(object sender, EventArgs e)
        {
            FormUpg.RewriteProcessNamesToListBox(checkListBox);
        }

        private void ButSaveProcNamesToFile_Click(object sender, EventArgs e)
        {
            FileWork.SaveProcNames(checkListBox.GetTextCheckeds());
            FormUpg.RewriteProcessNamesToListBox(checkListBox);
        }


        private void ButBack_Click(object sender, EventArgs e)
        {
            FormUpg.SmoothViewFormClose(this);
        }

    }
}
