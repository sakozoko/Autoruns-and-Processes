﻿using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Shitcleaner
{
    public static class CheckedListBoxExtension
    {
        public static void SetCheckeds(this CheckedListBox checkedListBox)
        {
            List<string> lists = FileWork.GetSavedProcNames();
            for (int i = 0; i < checkedListBox.Items.Count; i++)
            {
                foreach (string str in lists)
                {
                    if (checkedListBox.Items[i].ToString() == str)
                    {
                        checkedListBox.SetItemChecked(i, true);
                    }
                }
            }
        }
        public static List<string> GetTextCheckeds(this CheckedListBox checkedListBox)
        {
            return checkedListBox.CheckedItems.Cast<object>().GroupBy(g => g)
                .Select(g => checkedListBox.GetItemText(g.Key)).ToList();
        }

        public static void AddList(this CheckedListBox checkedListBox, List<string> list)
        {
            foreach (string str in list)
            {
                checkedListBox.Items.Add(str);
            }
        }


        //List
        public static List<T> UniqueElements<T>(this List<T> list)
        {
            return list.GroupBy(g => g).Where(g => g.Count() == 1).Select(g => g.Key).ToList();
        }
    }
}
