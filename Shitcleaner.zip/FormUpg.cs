﻿using System;
using System.Windows.Forms;

namespace Shitcleaner
{
    public class FormUpg
    {

        static EventHandler eventHandler;
        private static void StartTimer(EventHandler meth, Form myForm)
        {
            Timer timer = new Timer();
            meth += new EventHandler((s, e) =>
            {
                if (myForm.Opacity == 1 || myForm.Opacity == 0) timer.Stop();
            });
            meth += eventHandler;
            timer.Tick += meth;
            timer.Interval = 10;
            timer.Start();
        }

        public static void SmoothViewForm(Form myForm)
        {
            if (myForm.Opacity == 0)
            {
                eventHandler += new EventHandler((s, e) => { myForm.Opacity += 0.05;});
                StartTimer(eventHandler, myForm);
            }
            else
            {
                eventHandler += new EventHandler((s, e) =>{myForm.Opacity -= 0.05;});
                StartTimer(eventHandler, myForm);
            }
        }



        public static void SmoothViewFormClose(Form myForm)
        {
            if (myForm.Opacity == 1)
            { 
                eventHandler = new EventHandler((s, e) =>{if (myForm.Opacity == 0) myForm.Close();});
                SmoothViewForm(myForm);
            }
        }



        public static void SmoothViewFormMinNorm(Form myForm)
        {
            if (myForm.Opacity == 0)
            {
                eventHandler = new EventHandler((s, e) =>{myForm.WindowState = FormWindowState.Normal;});
                SmoothViewForm(myForm);
            }
            else
            {
                eventHandler = new EventHandler((s, e) =>{if (myForm.Opacity == 0) myForm.WindowState = FormWindowState.Minimized;});
                SmoothViewForm(myForm);
            }
        }



        public static void RewriteProcessNamesToListBox(CheckedListBox checkList)
        {
            checkList.Items.Clear();
            if (checkList.FindForm().Name == "FSavedProc")
                checkList.AddList(FileWork.GetSavedProcNames());
            else if(checkList.FindForm().Name == "MainForm")
                checkList.AddList(Processes.GetActivitedProcessNames().UniqueElements());
            checkList.SetCheckeds();
        }

        public class FormMove
        {
            private static int x, y;
            private static Form form;
            public static void PanelTitle_MouseDown(object sender, MouseEventArgs e, Form myForm)
            {
                form = myForm;
                x = e.X;
                y = e.Y;
            }

            public static void PanelTitle_MouseDoubleClick(object sender, MouseEventArgs e)
            {
                if (e.Button == MouseButtons.Left)
                {
                    form.WindowState = (form.WindowState == FormWindowState.Maximized) ? FormWindowState.Normal : FormWindowState.Maximized;
                }
            }

            public static void PanelTitle_MouseMove(object sender, MouseEventArgs e)
            {
                if (e.Button == MouseButtons.Left)
                {
                    form.Left = (form.Left + e.X) - x;
                    form.Top = (form.Top + e.Y) - y;
                }
            }
        }
    }



}
