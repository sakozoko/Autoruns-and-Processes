﻿using System.Collections.Generic;
using System.Diagnostics;

namespace Shitcleaner
{
    public class Processes
    {
        public static List<string> GetActivitedProcessNames()
        {
            Process[] processes = Process.GetProcesses();
            List<string> listProcessNames = new List<string>();
            foreach (Process proc in processes)
            {
                listProcessNames.Add(proc.ProcessName);
            }

            return listProcessNames;
        }


        public static void ProcessesKill(List<string> ProcessNames)
        {
            try
            {
                foreach (string str in ProcessNames)
                {
                    Process[] proc = Process.GetProcessesByName(str);
                    foreach (Process process in proc)
                    {
                        process.Kill();
                        process.WaitForExit();
                    }
                }
            }
            catch (System.ComponentModel.Win32Exception)
            {
                new FMessage("Отказано в доступе", "Запустите приложение от имени администратора!",
                    IconFMessage.Notification, ButtonFMessage.OK).ShowDialog();
            }
        }
    }
}
