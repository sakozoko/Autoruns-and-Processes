﻿using Shitcleaner.Properties;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Resources;

namespace Shitcleaner
{
    public class FileWork
    {
        private readonly string path = "SavedInfo.dbb";
        public static List<string> GetSavedProcNames()
        {
            List<string> procNames = new List<string>();
            using (StreamReader sr = new StreamReader(new FileStream(new FileWork().path, FileMode.OpenOrCreate)))
            {
                string str = sr.ReadLine();
                do
                {
                    if (str != null && str != "")
                        procNames.Add(str);
                    str = sr.ReadLine();
                }
                while (!(str is null));
            }
            return procNames;
        }

        private bool FileNeedNewLine()
        {
            bool fileNeedNewLine = false;
            using (StreamReader sr = new StreamReader(new FileWork().path))
            {
                string str = sr.ReadToEnd();
                if (!str.EndsWith("\n"))
                {
                    fileNeedNewLine = true;
                }
            }
            return fileNeedNewLine;
        }


        public static void AddProcNames(List<string> procNames)
        {
            try
            {
                bool fileNeedNewLine = new FileWork().FileNeedNewLine();
                procNames = procNames.Except(GetSavedProcNames()).ToList();
                using (StreamWriter sw = new StreamWriter(new FileWork().path, true))
                {
                    if (fileNeedNewLine)
                    {
                        sw.WriteLine();
                    }

                    new FileWork().WriteListToFile(procNames, sw);
                }
            }
            catch (FileNotFoundException)
            {
                new FMessage("Ошибка", "Файл хранения данных не найден!", IconFMessage.Notification, ButtonFMessage.OK).ShowDialog();
            }
        }


        public static void SaveProcNames(List<string> procNames)
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(new FileWork().path))
                {

                    new FileWork().WriteListToFile(procNames, sw);
                }

            }
            catch (FileNotFoundException)
            {
                new FMessage("Ошибка", "Файл хранения данных не найден!", IconFMessage.Notification, ButtonFMessage.OK).ShowDialog();
            }
        }

        private void WriteListToFile(List<string> procNames, StreamWriter sw)
        {
            foreach (string str in procNames)
            {
                sw.WriteLine(str);
            }
        }
    }
}
