﻿
namespace Shitcleaner
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.checkList = new System.Windows.Forms.CheckedListBox();
            this.butSave = new System.Windows.Forms.Button();
            this.butKill = new System.Windows.Forms.Button();
            this.butRefresh = new System.Windows.Forms.Button();
            this.notifyIcon = new System.Windows.Forms.NotifyIcon(this.components);
            this.contextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.OpenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CleanProcessesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CloseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.butShowSavedProc = new System.Windows.Forms.Button();
            this.panelBody = new System.Windows.Forms.Panel();
            this.panelStatus = new System.Windows.Forms.Panel();
            this.icon = new System.Windows.Forms.PictureBox();
            this.butMaximize = new System.Windows.Forms.Button();
            this.butCloseProgram = new System.Windows.Forms.Button();
            this.butMinimize = new System.Windows.Forms.Button();
            this.panelFoot = new System.Windows.Forms.Panel();
            this.contextMenuStrip.SuspendLayout();
            this.panelBody.SuspendLayout();
            this.panelStatus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.icon)).BeginInit();
            this.SuspendLayout();
            // 
            // checkList
            // 
            this.checkList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.checkList.BackColor = System.Drawing.Color.Black;
            this.checkList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.checkList.CheckOnClick = true;
            this.checkList.ForeColor = System.Drawing.SystemColors.Window;
            this.checkList.FormattingEnabled = true;
            this.checkList.Location = new System.Drawing.Point(10, 26);
            this.checkList.Margin = new System.Windows.Forms.Padding(5);
            this.checkList.Name = "checkList";
            this.checkList.Size = new System.Drawing.Size(691, 285);
            this.checkList.Sorted = true;
            this.checkList.TabIndex = 0;
            // 
            // butSave
            // 
            this.butSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.butSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.butSave.FlatAppearance.BorderSize = 0;
            this.butSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(55)))), ((int)(((byte)(55)))));
            this.butSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.butSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butSave.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.butSave.Location = new System.Drawing.Point(13, 358);
            this.butSave.Name = "butSave";
            this.butSave.Size = new System.Drawing.Size(124, 42);
            this.butSave.TabIndex = 1;
            this.butSave.Text = "Сохранить процессы";
            this.butSave.UseVisualStyleBackColor = false;
            this.butSave.Click += new System.EventHandler(this.ButAddProcNamesToFile_Click);
            // 
            // butKill
            // 
            this.butKill.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.butKill.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.butKill.FlatAppearance.BorderSize = 0;
            this.butKill.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(55)))), ((int)(((byte)(55)))));
            this.butKill.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.butKill.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butKill.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.butKill.Location = new System.Drawing.Point(286, 358);
            this.butKill.Name = "butKill";
            this.butKill.Size = new System.Drawing.Size(124, 42);
            this.butKill.TabIndex = 2;
            this.butKill.Text = "Убить процессы";
            this.butKill.UseVisualStyleBackColor = false;
            this.butKill.Click += new System.EventHandler(this.ButCleanProcesses_Click);
            // 
            // butRefresh
            // 
            this.butRefresh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.butRefresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.butRefresh.FlatAppearance.BorderSize = 0;
            this.butRefresh.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(55)))), ((int)(((byte)(55)))));
            this.butRefresh.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.butRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butRefresh.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.butRefresh.Location = new System.Drawing.Point(580, 358);
            this.butRefresh.Name = "butRefresh";
            this.butRefresh.Size = new System.Drawing.Size(124, 42);
            this.butRefresh.TabIndex = 3;
            this.butRefresh.Text = "Обновить листбокс";
            this.butRefresh.UseVisualStyleBackColor = false;
            this.butRefresh.Click += new System.EventHandler(this.ButRefreshListBox_Click);
            // 
            // notifyIcon
            // 
            this.notifyIcon.BalloonTipText = "Нажмите, чтобы отобразить";
            this.notifyIcon.BalloonTipTitle = "ShitCleaner";
            this.notifyIcon.ContextMenuStrip = this.contextMenuStrip;
            this.notifyIcon.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon.Icon")));
            this.notifyIcon.Text = "ShitCleaner";
            this.notifyIcon.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.NotifyIcon_MouseDoubleClick);
            // 
            // contextMenuStrip
            // 
            this.contextMenuStrip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.contextMenuStrip.DropShadowEnabled = false;
            this.contextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.OpenToolStripMenuItem,
            this.CleanProcessesToolStripMenuItem,
            this.CloseToolStripMenuItem});
            this.contextMenuStrip.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Table;
            this.contextMenuStrip.Name = "contextMenuStrip1";
            this.contextMenuStrip.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.contextMenuStrip.ShowImageMargin = false;
            this.contextMenuStrip.ShowItemToolTips = false;
            this.contextMenuStrip.Size = new System.Drawing.Size(155, 70);
            // 
            // OpenToolStripMenuItem
            // 
            this.OpenToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.OpenToolStripMenuItem.Name = "OpenToolStripMenuItem";
            this.OpenToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.OpenToolStripMenuItem.Text = "Открыть";
            this.OpenToolStripMenuItem.Click += new System.EventHandler(this.OpenToolStripMenuItem_Click);
            // 
            // CleanProcessesToolStripMenuItem
            // 
            this.CleanProcessesToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.CleanProcessesToolStripMenuItem.Name = "CleanProcessesToolStripMenuItem";
            this.CleanProcessesToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.CleanProcessesToolStripMenuItem.Text = "Почистить процессы";
            this.CleanProcessesToolStripMenuItem.Click += new System.EventHandler(this.CleanProcessesToolStripMenuItem_Click);
            // 
            // CloseToolStripMenuItem
            // 
            this.CloseToolStripMenuItem.AutoSize = false;
            this.CloseToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.CloseToolStripMenuItem.Name = "CloseToolStripMenuItem";
            this.CloseToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.CloseToolStripMenuItem.Text = "Закрыть";
            this.CloseToolStripMenuItem.Click += new System.EventHandler(this.CloseProgramToolStripMenuItem_Click);
            // 
            // butShowSavedProc
            // 
            this.butShowSavedProc.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.butShowSavedProc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.butShowSavedProc.FlatAppearance.BorderSize = 0;
            this.butShowSavedProc.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(55)))), ((int)(((byte)(55)))));
            this.butShowSavedProc.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.butShowSavedProc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butShowSavedProc.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.butShowSavedProc.Location = new System.Drawing.Point(433, 358);
            this.butShowSavedProc.Name = "butShowSavedProc";
            this.butShowSavedProc.Size = new System.Drawing.Size(124, 42);
            this.butShowSavedProc.TabIndex = 4;
            this.butShowSavedProc.Text = "Сохраненные процессы";
            this.butShowSavedProc.UseVisualStyleBackColor = false;
            this.butShowSavedProc.Click += new System.EventHandler(this.ButShowSavedProc_Click);
            // 
            // panelBody
            // 
            this.panelBody.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelBody.BackColor = System.Drawing.Color.Black;
            this.panelBody.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelBody.Controls.Add(this.checkList);
            this.panelBody.Location = new System.Drawing.Point(0, 26);
            this.panelBody.Name = "panelBody";
            this.panelBody.Size = new System.Drawing.Size(716, 318);
            this.panelBody.TabIndex = 5;
            // 
            // panelStatus
            // 
            this.panelStatus.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelStatus.Controls.Add(this.icon);
            this.panelStatus.Controls.Add(this.butMaximize);
            this.panelStatus.Controls.Add(this.butCloseProgram);
            this.panelStatus.Controls.Add(this.butMinimize);
            this.panelStatus.Location = new System.Drawing.Point(0, 0);
            this.panelStatus.Margin = new System.Windows.Forms.Padding(0);
            this.panelStatus.Name = "panelStatus";
            this.panelStatus.Size = new System.Drawing.Size(716, 30);
            this.panelStatus.TabIndex = 9;
            this.panelStatus.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.PanelTitle_MouseDoubleClick);
            this.panelStatus.MouseDown += new System.Windows.Forms.MouseEventHandler(this.PanelTitle_MouseDown);
            this.panelStatus.MouseMove += new System.Windows.Forms.MouseEventHandler(this.PanelTitle_MouseMove);
            // 
            // icon
            // 
            this.icon.Image = global::Shitcleaner.Properties.Resources.icon;
            this.icon.Location = new System.Drawing.Point(11, 0);
            this.icon.Name = "icon";
            this.icon.Padding = new System.Windows.Forms.Padding(5);
            this.icon.Size = new System.Drawing.Size(31, 30);
            this.icon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.icon.TabIndex = 9;
            this.icon.TabStop = false;
            // 
            // butMaximize
            // 
            this.butMaximize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.butMaximize.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.butMaximize.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.butMaximize.FlatAppearance.BorderSize = 0;
            this.butMaximize.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.butMaximize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(55)))), ((int)(((byte)(55)))));
            this.butMaximize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butMaximize.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.butMaximize.Location = new System.Drawing.Point(634, 0);
            this.butMaximize.Margin = new System.Windows.Forms.Padding(0);
            this.butMaximize.Name = "butMaximize";
            this.butMaximize.Size = new System.Drawing.Size(40, 30);
            this.butMaximize.TabIndex = 7;
            this.butMaximize.UseVisualStyleBackColor = false;
            this.butMaximize.Click += new System.EventHandler(this.ButMaximize_Click);
            // 
            // butCloseProgram
            // 
            this.butCloseProgram.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.butCloseProgram.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.butCloseProgram.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.butCloseProgram.FlatAppearance.BorderSize = 0;
            this.butCloseProgram.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.butCloseProgram.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(55)))), ((int)(((byte)(55)))));
            this.butCloseProgram.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butCloseProgram.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.butCloseProgram.Image = global::Shitcleaner.Properties.Resources.x;
            this.butCloseProgram.Location = new System.Drawing.Point(674, 0);
            this.butCloseProgram.Margin = new System.Windows.Forms.Padding(0);
            this.butCloseProgram.Name = "butCloseProgram";
            this.butCloseProgram.Size = new System.Drawing.Size(40, 30);
            this.butCloseProgram.TabIndex = 6;
            this.butCloseProgram.UseVisualStyleBackColor = false;
            this.butCloseProgram.Click += new System.EventHandler(this.ButCloseProgram_Click);
            // 
            // butMinimize
            // 
            this.butMinimize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.butMinimize.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.butMinimize.FlatAppearance.BorderSize = 0;
            this.butMinimize.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.butMinimize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(55)))), ((int)(((byte)(55)))));
            this.butMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butMinimize.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.butMinimize.Image = global::Shitcleaner.Properties.Resources.minus;
            this.butMinimize.Location = new System.Drawing.Point(594, 0);
            this.butMinimize.Name = "butMinimize";
            this.butMinimize.Size = new System.Drawing.Size(40, 30);
            this.butMinimize.TabIndex = 8;
            this.butMinimize.UseVisualStyleBackColor = false;
            this.butMinimize.Click += new System.EventHandler(this.ButMinimize_Click);
            // 
            // panelFoot
            // 
            this.panelFoot.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelFoot.Location = new System.Drawing.Point(0, 343);
            this.panelFoot.Name = "panelFoot";
            this.panelFoot.Size = new System.Drawing.Size(716, 68);
            this.panelFoot.TabIndex = 10;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.ClientSize = new System.Drawing.Size(716, 412);
            this.Controls.Add(this.butShowSavedProc);
            this.Controls.Add(this.butRefresh);
            this.Controls.Add(this.butKill);
            this.Controls.Add(this.butSave);
            this.Controls.Add(this.panelStatus);
            this.Controls.Add(this.panelBody);
            this.Controls.Add(this.panelFoot);
            this.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.Opacity = 0D;
            this.Text = "ProcessCleaner";
            this.Deactivate += new System.EventHandler(this.MainForm_Deactivate);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.contextMenuStrip.ResumeLayout(false);
            this.panelBody.ResumeLayout(false);
            this.panelStatus.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.icon)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.CheckedListBox checkList;
        private System.Windows.Forms.Button butSave;
        private System.Windows.Forms.Button butKill;
        private System.Windows.Forms.Button butRefresh;
        private System.Windows.Forms.NotifyIcon notifyIcon;
        private System.Windows.Forms.Button butShowSavedProc;
        private System.Windows.Forms.Panel panelBody;
        private System.Windows.Forms.Button butCloseProgram;
        private System.Windows.Forms.Button butMaximize;
        private System.Windows.Forms.Button butMinimize;
        private System.Windows.Forms.Panel panelStatus;
        private System.Windows.Forms.PictureBox icon;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem OpenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem CleanProcessesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem CloseToolStripMenuItem;
        private System.Windows.Forms.Panel panelFoot;
    }
}

